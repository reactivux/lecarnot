export const getCartStore = (state) => {
    return state.cartStore
}

export const isLoggedIn = (state) => {
    return state.userStore.isLoggedIn
}
