export interface SubElementsOrder {
  type: string
  price: number
  quantity: number
  sub_product_id: number,
  promo: Object
}
