export interface Category {
    id: number,
    name?:string,
    store_id?: number,
    logo?: string,
    description?: string,
    products?: []
}
    