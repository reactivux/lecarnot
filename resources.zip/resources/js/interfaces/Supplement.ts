export interface Supplement{
    id:number;
    name:string;
}