<section class="section section-contact df__pt  primary-bg  position-relative w-100">
     <div class="row  position-relative g-0">
         <div class="col-md-4 cateory-bg cateory-bg-primary bg-img-pizza-creme-fraiche">
             <div class="  p-4 h-100 content-category">
                <div class="heading ">
                    <h2 class="title title-h2-left ">
                        Nos Pizzas Spéciales
                    </h2>
                </div>
                <p class="text">
                    Recettes uniques et pleines de surprises.
                </p>
                <a href="/produits/#Nos%20pizza%20spéciales" class="buttons buttons-theme-cta-1  buttons-themex-border buttons-md mt-3">
                    Commander
                </a>
             </div>
         </div>
         <div class="col-md-4 cateory-bg cateory-bg-white bg-img-pizza-sauce-tomate">
             <div class="  p-4 h-100 content-category">
                 <div class="heading ">
                     <h2 class="title title-h2-left ">
                        Nos Pizzas Crème Fraîche
                     </h2>
                 </div>
                 <p class="text">
                    Pizzas douces et fondantes à la crème.
                 </p>
                 <a href="/produits/#Nos%20pizza%20Crème%20fraiche" class="buttons buttons-theme-cta-2 buttons-themex-border buttons-md mt-3">
                     Commander
                 </a>
             </div>
         </div>
         <div class="col-md-4 cateory-bg cateory-bg-secondary bg-img-pizza-special">
             <div class="  p-4 h-100 content-category">
                 <div class="heading ">
                    <h2 class="title title-h2-left ">
                       Nos Pizzas Sauce Tomate
                    </h2>
                </div>
                <p class="text">
                   Classiques à base de sauce tomate maison.
                </p>
                <a href="/produits/#Nos%20pizza%20Sauce%20Tomate" class="buttons buttons-theme-cta-3  buttons-themex-border buttons-md mt-3">
                    Commander
                </a>
             </div>
         </div>
     </div>
 </section>