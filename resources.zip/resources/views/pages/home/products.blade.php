 @if ($categoriesProducts)
     <home-category-products :categories="{{ json_encode($categoriesProducts) }}"> </home-category-products>
 @endif
