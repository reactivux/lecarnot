 <section class="section section-promotions df__pt   secondary-bg position-relative">
     <div class="container">
         <div class="row wow fadeInUp position-relative">
             <div class="col-12">
                 <div class="heading ">
                     <h3 class="subtitle subtitle-h3 ">Une variété alléchante de délices à déguster</h3>
                     <h2 class="title title-h2 title-h2-center">Toutes nos promotions </h2>
                 </div>
             </div>
             <div class="col-md-6 ">
                 <a href="">
                     <img loading="lazy" decoding="async" width="450" height="450"
                         src="{{ asset('img/promo.webp') }}" class="attachment-thumbnail size-thumbnail" alt="">
                 </a>
             </div>
             <div class="col-md-6 ">
                 <a href="">
                     <img loading="lazy" decoding="async" width="450" height="450"
                         src="{{ asset('img/goutes-la-difference.webp') }}" class="attachment-thumbnail size-thumbnail"
                         alt="">
                 </a>
             </div>

         </div>
     </div>
 </section>
