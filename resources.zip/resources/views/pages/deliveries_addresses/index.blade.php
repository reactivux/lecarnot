@extends('layouts.master')
@section('meta')
    <title>Le Carnot - Adresses de livraison – Fast Food Gourmand à Le Neubourg </title>
    <meta name="description"
        content="Chez Le Carnot, partagez un moment convivial autour de burgers, tacos, pizzas et sandwichs faits maison. Des recettes généreuses et une ambiance chaleureuse au cœur du Neubourg !">
    <meta name="keywords"
        content="4 fromages,Régina,La Le Carnot,Suprême,Cheddar,Végétarienne,Classico,Fruits de mer,Maxi,Tomate,Mozzarella,merguez,viande hachée,origan,oignon rouge,Burrata,Sevilla,Hyptnotika,pizzas savoureuses,pizza maison,livraison rapide,pâte fraîche,pizzas spéciales,pizzas gourmandes">
    <meta property="og:url" content="{{ route('home') }}">
    <meta property="og:type" content="article">
    <meta property="og:title" content="Le Carnot - Adresses de livraison – Fast Food Gourmand à Le Neubourg ">
    <meta property="og:description"
        content="Chez Le Carnot, partagez un moment convivial autour de burgers, tacos, pizzas et sandwichs faits maison. Des recettes généreuses et une ambiance chaleureuse au cœur du Neubourg !">
    <meta property="og:image" content="{{ asset('img/pizza.webp') }}">
@endsection
@section('content')
    <section class="breadcrumb m_0">
        <div class="breadcrumb_overlay">
            <div class="container">
                <div class="breadcrumb_text">
                    <h1 class="title title-h1">Vos adresses de livraison</h1>
                    <ul>
                        <li><a href="/" class="">Accueil</a></li>
                        <li><a class="link-bold">Adresse</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class=" df__pt df__pb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 wow fadeInUp">
                    <div class="tf_dashboard_order">
                        <div class="table-responsive">
                            {{-- @if ($deliveriesAddresses) --}}
                            {{-- <deliveries-addresses :deliveries-addresses="{{ json_encode($deliveriesAddresses) }}"
                                key="list-addresses"></deliveries-addresses> --}}
                            {{-- @endif --}}
                            <deliveries-addresses key="list-addresses"></deliveries-addresses>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
